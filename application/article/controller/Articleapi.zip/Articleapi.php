<?php
/**
 * 文章控制器.
 * User: fukunari<fukunari@163.com>
 * Date: 2018-11-12
 */

namespace app\article\controller;


use app\common\controller\Api;
use app\article\validate\Article as ArticleValidate;

class Articleapi extends Api {
    /**
     * 获取文章列表
     * @return array
     */
    public function index() {
        $param = request()->param('data');

        $validate = new ArticleValidate();
        if (!$validate->scene('list')->check($param)) {
            $this->response['code'] = 0;
            $this->response['msg'] = $validate->getError();
            return $this->response;
        }

        $queryWhere = [
            ['article_is_single', 'eq', 0],
            ['article_column_id', 'eq', 8],
        ];
        if (isset($param['keyword'])) {
            $queryWhere[] = ['article_title', 'like', '%'.$param['keyword'].'%'];
        }
        if (!isset($param['limit'])) {
            $param['limit'] = 10;
        }
        if (!isset($param['page'])) {
            $param['page'] = 1;
        }
        if (isset($param['attr']) && !empty($param['attr'])) {
            $queryWhere[] = ['article_attr', 'eq', 1];
        }

        $data = db('article')->where($queryWhere)->limit($param['limit'])->page($param['page'])->field(['article_id', 'article_title', 'article_thumb', 'article_brief', 'article_comment_num', 'article_zan_num'])->select();
        $this->response['response'] = $data;
//		dump($this->response);exit;
        return $this->response;
    }

    /**
     * 获取文章详情
     * @return array
     */
    public function item() {
        $param = request()->param('data');

        // 数据验证
        $validate = new ArticleValidate();
        if (!$validate->scene('item')->check($param)) {
            $this->response['code'] = 0;
            $this->response['msg'] = $validate->getError();
            return $this->response;
        }

        $data = [
            'article' => [],
            'comment' => [],
        ];
        // 获取文章详情
        $article = db('article')->where(['article_id' => $param['articleId']])->find();
        $data['article'] = $article;

        // 获取评论
        /*if ($article['article_id']) {
            $commentWhere = [
                'comment_article_id' => $article['article_id'],
                'comment_status' => 1,
            ];
            $comment = db('article_comment')->where($commentWhere)->select();
            $data['comment'] = $comment;
        }*/
        $data['comment'] = $this->discuss($param['articleId']);

        // 是否收藏
        $data['article']['is_collect'] = 0;
        if (empty($param['userId'])) {
            $collectWhere = [
                'collect_object_id' => $article['article_id'],
                'collect_user_id' => $param['userId'],
                'collect_type' => 2,
            ];
            $isCollect = db('collect_log')->where($collectWhere)->count();
            $data['article']['is_collect'] = $isCollect;
        }

        $this->response['response'] = $data;
        return $this->response;
    }


	/**
	 * 评论列表
	 * @return array
	 * @throws \think\db\exception\DataNotFoundException
	 * @throws \think\db\exception\ModelNotFoundException
	 * @throws \think\exception\DbException
	 */
	public function discuss($article) {
//		$param = request()->param('data');
//
//		// 数据验证
//		$validate = new ArticleValidate();
//		if (!$validate->scene('discuss')->check($param)) {
//			$this->response['code'] = 0;
//			$this->response['msg'] = $validate->getError();
//			return $this->response;
//		}

		$param['articleId'] = $article;

		// 获取评论
		if ($param['articleId']) {
			$commentWhere = [
				'comment_article_id' => $param['articleId'],
				'comment_status' => 1,
			];
			$comment = db('article_comment')->alias("A")
						->join("users B","A.comment_user_id = B.user_id",'left')
						->field("A.*,B.user_headpic,B.user_nickname")
						->where($commentWhere)->where("B.user_status",1)->select();
		}
		$commentData = [];
		if (!empty($comment)){
			foreach ($comment as $key => $value){
				if ($value['comment_pid'] == 0){
					$commentData[] = $value;
				}
			}
			if (!empty($commentData)){
				foreach ($commentData as $k=> $v){
					foreach ($comment as $m => $n){
						if ($v['comment_id'] == $n['comment_pid']){
							$comment[$k]['comment_list'][] = $n;
						}
					}
				}
			}
			foreach ($comment as $t => $s){
				if ($s['comment_pid'] != 0){
					unset($comment[$t]);
				}
				if (!isset($s['comment_list']) && $s['comment_pid'] == 0){
					$comment[$t]['comment_list'] = [];
				}
			}
		}

		$comment = array_values($comment);

		return $comment;

//		dump($comment);exit;

//		$this->response['response'] = $comment;
//		return $this->response;
	}



    /**
     * 文章计数器
     * @return array
     */
    public function count() {
        $param = request()->param('data');

        // 数据验证
        $validate = new ArticleValidate();
        if (!$validate->scene('count')->check($param)) {
            $this->response['code'] = 0;
            $this->response['msg'] = $validate->getError();
            return $this->response;
        }

        // 对什么字段进行计数
        $inc = '';
        switch ($param['type']) {
            case 'view': $inc = 'article_view_num'; break;
            case 'zan': $inc = 'article_zan_num'; break;
            default: break;
        }

        // 没有计数对象直接返回
        if (empty($inc)) return $this->response;

        $queryWhere = [
            'article_id' => $param['articleId'],
        ];
        db('article')->where($queryWhere)->setInc($inc);

        return $this->response;
    }

    /**
     * 收藏攻略
     * @return array
     */
    public function collect() {
        $param = request()->param('data');

        // 数据验证
        $validate = new ArticleValidate();
        if (!$validate->scene('item')->check($param)) {
            $this->response['code'] = 0;
            $this->response['msg'] = $validate->getError();
            return $this->response;
        }

        $saveData = [
            'collect_user_id' => $param['userId'],
            'collect_object_id' => $param['articleId'],
            'collect_create_time' => time(),
            'collect_type' => 2,
        ];
        db('collect_log')->insert($saveData);

        // 增加收藏计数
        db('article')->where(['article_id' => $param['articleId']])->setInc('article_collect_num');

        return $this->response;
    }

    /**
     * 取消收藏
     * @return array
     */
    public function rmCollect() {
        $param = request()->param('data');

        // 数据验证
        $validate = new ArticleValidate();
        if (!$validate->scene('item')->check($param)) {
            $this->response['code'] = 0;
            $this->response['msg'] = $validate->getError();
            return $this->response;
        }

        $queryWhere = [
            'collect_user_id' => $param['userId'],
            'collect_object_id' => $param['articleId'],
            'collect_type' => 2,
        ];
        db('collect_log')->where($queryWhere)->delete();

        // 减少收藏计数
        db('article')->where(['article_id' => $param['articleId']])->setDec('article_collect_num');

        return $this->response;
    }

    /**
     * 回复评论
     * @return array
     */
    public function comment() {
        $param = request()->param('data');

        // 数据验证
        $validate = new ArticleValidate();
        if (!$validate->scene('comment')->check($param)) {
            $this->response['code'] = 0;
            $this->response['msg'] = $validate->getError();
            return $this->response;
        }

        $saveData = [
            'comment_user_id' => $param['userId'],
            'comment_article_id' => $param['articleId'],
            'comment_pid' => $param['commentId'],
            'comment_create_time' => time(),
            'comment_content' => $param['content'],
        ];
        db('article_comment')->insert($saveData);

        // 增加评论计数
        db('article')->where(['article_id' => $param['articleId']])->setInc('article_comment_num');

        return $this->response;
    }

    /**
     * 常见问题
     * @return array
     */
    public function faq(){
        $queryWhere = [
            'article_column_id' => 9,
        ];

        $data = db('article')->where($queryWhere)->field(['article_id', 'article_title', 'article_brief'])->select();
        $this->response['response'] = $data;

        return $this->response;
    }


	/**
	 * 评论点赞
	 * @return array
	 */
	public function commentZan() {
		$param = request()->param('data');

		// 数据验证
		$validate = new ArticleValidate();
		if (!$validate->scene('commentZan')->check($param)) {
			$this->response['code'] = 0;
			$this->response['msg'] = $validate->getError();
			return $this->response;
		}

		// 增加评论计数
		db('article_comment')->where(['comment_id' => $param['commentId']])->setInc('comment_zan_num');

		return $this->response;
	}


}